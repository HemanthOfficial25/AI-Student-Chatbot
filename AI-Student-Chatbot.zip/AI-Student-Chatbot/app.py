# -*- coding: utf-8 -*-
"""
app.py
------
Flask entry point for the AI Student Chatbot.

Routes:
    GET  /            -> Renders the chat UI (templates/index.html)
    POST /get_response -> Accepts a JSON user message, returns the bot's
                           JSON reply computed by chatbot.FAQChatbot

Run with:
    python app.py
The server starts at http://127.0.0.1:5000
"""

from flask import Flask, render_template, request, jsonify

from chatbot import FAQChatbot

app = Flask(__name__)

# Build the FAQ vector space once at startup instead of on every request —
# this keeps each chat response fast.
bot = FAQChatbot()


@app.route("/")
def index():
    """Serve the main chat interface."""
    return render_template("index.html")


@app.route("/get_response", methods=["POST"])
def get_response():
    """
    Main chatbot API endpoint.

    Expects JSON: {"message": "<user question>"}
    Returns JSON: {"reply": "<bot answer>"}
    """
    data = request.get_json(silent=True) or {}
    user_message = data.get("message", "")

    result = bot.get_response(user_message)

    return jsonify({
        "reply": result["answer"],
        "score": round(result["score"], 3),
    })


if __name__ == "__main__":
    # debug=True gives auto-reload + helpful error pages during development.
    # Turn this off (or use a production WSGI server) before deploying.
    app.run(debug=True)
