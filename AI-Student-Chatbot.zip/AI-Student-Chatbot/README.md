# 🎓 AI Chatbot for Student Queries — Campus Assist

An offline, AI-powered FAQ chatbot built for a college minor project. It
answers common student questions about **admissions, fees, courses,
placements, hostel, scholarships, library, college timings, faculty, and
contact details** — entirely offline, using classic NLP (no paid APIs, no
internet-dependent AI service).

---

## ✨ Features

- **ChatGPT-style chat UI** — bubbles, avatars, typing indicator, auto-scroll
- **Enter to send**, Shift+Enter for a new line
- **Fully responsive** — works on desktop, tablet, and mobile
- **Offline NLP matching** — TF-IDF Vectorizer + Cosine Similarity
  (scikit-learn), no external AI/API calls
- **120+ FAQ entries** across 10 categories in `data/faq.csv`
- **Graceful fallback** — if no FAQ is a confident match, the bot replies:
  > "Sorry, I couldn't understand your question. Please contact the administration."
- Clean, modular, commented Python/JS/HTML/CSS code

---

## 🗂 Project Structure

```
AI-Student-Chatbot/
│
├── app.py                 # Flask server & API route
├── chatbot.py              # TF-IDF + cosine similarity matching engine
├── requirements.txt        # Python dependencies
├── README.md                # This file
├── data/
│   └── faq.csv               # 120+ FAQ question/answer/category rows
├── templates/
│   └── index.html            # Chat UI markup
└── static/
    ├── style.css              # Chat UI styling (responsive)
    └── script.js               # Chat interactions (fetch, render, scroll)
```

---

## ⚙️ How It Works

1. On startup, `app.py` creates one `FAQChatbot` instance (`chatbot.py`).
2. `FAQChatbot` loads every row of `data/faq.csv` and fits a
   **TF-IDF vectorizer** over all the FAQ *questions* (unigrams + bigrams,
   English stop words removed).
3. When a user sends a message, it is cleaned the same way and transformed
   into that same TF-IDF vector space (not re-fit — just transformed).
4. **Cosine similarity** is computed between the user's vector and every
   FAQ question vector. The highest-scoring FAQ's answer is returned.
5. If the best similarity score is below a threshold (`0.25` by default,
   tunable in `chatbot.py`), the bot returns the fallback message instead
   of guessing.

All of this runs locally in Python with `scikit-learn` — **no internet
connection or paid API key is required** to get chatbot answers.

---

## 🚀 Installation & Setup

### 1. Prerequisites
- Python 3.9+ installed
- `pip` available on your PATH

### 2. Clone / download the project
```bash
cd AI-Student-Chatbot
```

### 3. (Recommended) Create a virtual environment
```bash
python -m venv venv

# Activate it:
# Windows:
venv\Scripts\activate
# macOS / Linux:
source venv/bin/activate
```

### 4. Install dependencies
```bash
pip install -r requirements.txt
```

### 5. Run the app
```bash
python app.py
```

### 6. Open the chatbot
Visit **http://127.0.0.1:5000** in your browser.

---

## 🧪 Testing the Matching Engine Directly

You can sanity-check the NLP logic without Flask by running:
```bash
python chatbot.py
```
This prints sample queries and the bot's matched answer + similarity score.

---

## 📝 Adding / Editing FAQs

Open `data/faq.csv` and add a new row with three columns:

```csv
category,question,answer
fees,Is there a fee for re-evaluation?,Yes; a nominal fee is charged per subject for re-evaluation requests.
```

Restart `app.py` after editing the CSV so the vectorizer is refit with the
new data.

---

## 🔌 API Reference

### `POST /get_response`

**Request body:**
```json
{ "message": "How can I apply for admission?" }
```

**Response body:**
```json
{ "reply": "You can apply online through the college admissions portal...", "score": 0.62 }
```

- `reply` — the matched FAQ answer, or the fallback message
- `score` — cosine similarity score (0 to 1) of the best match, for debugging/UX

---

## 🛠 Tech Stack

| Layer      | Technology                          |
|------------|--------------------------------------|
| Backend    | Python, Flask                        |
| NLP Engine | scikit-learn (TfidfVectorizer, cosine_similarity) |
| Frontend   | HTML5, CSS3, vanilla JavaScript      |
| Data       | CSV (`data/faq.csv`)                 |

---

## 📌 Notes for Evaluators

- This chatbot is **retrieval-based**, not generative — it never invents
  answers. It only returns text already present in `faq.csv`.
- It works fully offline once dependencies are installed; no OpenAI/Anthropic/
  other paid API keys are used anywhere in the code.
- The similarity threshold in `chatbot.py` (`SIMILARITY_THRESHOLD`) can be
  tuned to make the bot stricter or more lenient in what it considers a match.

---

## 📄 License

This project was built for academic purposes as part of a college minor
project submission. Free to reuse and modify for educational use.
