/**
 * script.js
 * ---------
 * Handles all client-side chat interactions for Campus Assist:
 *  - sending a message on button click / Enter key
 *  - rendering user & bot chat bubbles
 *  - showing a typing indicator while waiting for the Flask API
 *  - auto-scrolling the chat window
 *  - auto-resizing the textarea
 *  - wiring up the quick-suggestion chips
 */

(function () {
  "use strict";

  const chatWindow = document.getElementById("chat-window");
  const userInput = document.getElementById("user-input");
  const sendBtn = document.getElementById("send-btn");
  const suggestions = document.getElementById("suggestions");

  /**
   * Append a chat bubble to the window.
   * @param {"user"|"bot"} sender
   * @param {string} text
   * @returns {HTMLElement} the created message node
   */
  function appendMessage(sender, text) {
    const wrapper = document.createElement("div");
    wrapper.className = `message ${sender}-message`;

    const avatar = document.createElement("div");
    avatar.className = `avatar ${sender}-avatar`;
    avatar.textContent = sender === "user" ? "You" : "CA";

    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.textContent = text;

    wrapper.appendChild(avatar);
    wrapper.appendChild(bubble);
    chatWindow.appendChild(wrapper);

    scrollToBottom();
    return wrapper;
  }

  /** Show an animated "typing…" bubble and return its node so it can be removed later. */
  function showTypingIndicator() {
    const wrapper = document.createElement("div");
    wrapper.className = "message bot-message typing";
    wrapper.innerHTML = `
      <div class="avatar bot-avatar">CA</div>
      <div class="bubble">
        <span class="dot-flash"></span>
        <span class="dot-flash"></span>
        <span class="dot-flash"></span>
      </div>
    `;
    chatWindow.appendChild(wrapper);
    scrollToBottom();
    return wrapper;
  }

  function scrollToBottom() {
    chatWindow.scrollTop = chatWindow.scrollHeight;
  }

  /** Auto-grow the textarea up to a max height defined in CSS. */
  function autoResizeInput() {
    userInput.style.height = "auto";
    userInput.style.height = Math.min(userInput.scrollHeight, 120) + "px";
  }

  /** Send the current input value to the backend and render the reply. */
  async function sendMessage(rawText) {
    const text = (rawText !== undefined ? rawText : userInput.value).trim();
    if (!text) return;

    appendMessage("user", text);
    userInput.value = "";
    autoResizeInput();
    sendBtn.disabled = true;

    const typingNode = showTypingIndicator();

    try {
      const response = await fetch("/get_response", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      });

      if (!response.ok) {
        throw new Error(`Server responded with ${response.status}`);
      }

      const data = await response.json();
      typingNode.remove();
      appendMessage("bot", data.reply);
    } catch (err) {
      typingNode.remove();
      appendMessage(
        "bot",
        "Something went wrong reaching the server. Please make sure app.py is running and try again."
      );
      console.error("Chatbot request failed:", err);
    } finally {
      sendBtn.disabled = false;
      userInput.focus();
    }
  }

  // ---- Event wiring -------------------------------------------------

  sendBtn.addEventListener("click", () => sendMessage());

  // Enter sends the message; Shift+Enter inserts a newline.
  userInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  userInput.addEventListener("input", autoResizeInput);

  // Quick suggestion chips populate + send the sample question.
  suggestions.addEventListener("click", (e) => {
    const chip = e.target.closest(".chip");
    if (!chip) return;
    sendMessage(chip.dataset.q);
  });

  // Focus the input as soon as the page is ready.
  window.addEventListener("DOMContentLoaded", () => userInput.focus());
})();
