# -*- coding: utf-8 -*-
"""
chatbot.py
----------
Core NLP logic for the AI Student Chatbot.

This module loads the FAQ dataset (data/faq.csv), converts every FAQ
question into a TF-IDF vector, and matches an incoming user question
against that vector space using cosine similarity.

No external/paid AI APIs are used — everything runs locally with
scikit-learn, which is why the whole app works completely offline.
"""

import os
import re
import csv

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# Path to the FAQ dataset (relative to this file, so it works regardless
# of the directory the app is launched from).
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FAQ_CSV_PATH = os.path.join(BASE_DIR, "data", "faq.csv")

# If the best match's similarity score is below this threshold, the bot
# admits it doesn't understand instead of returning a low-quality guess.
SIMILARITY_THRESHOLD = 0.25

# Generic fallback message required by the project spec.
FALLBACK_MESSAGE = (
    "Sorry, I couldn't understand your question. "
    "Please contact the administration."
)


def clean_text(text: str) -> str:
    """
    Normalize text before vectorizing:
    - lowercase
    - strip punctuation/extra symbols
    - collapse repeated whitespace

    Keeping this identical for both FAQ questions and user input ensures
    the TF-IDF vector space treats them consistently.
    """
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


class FAQChatbot:
    """
    Encapsulates the FAQ dataset and the TF-IDF + cosine similarity
    matching logic. Instantiated once at app startup so the (relatively
    expensive) vectorizer fitting only happens a single time.
    """

    def __init__(self, csv_path: str = FAQ_CSV_PATH):
        self.csv_path = csv_path
        self.questions = []      # original question text (for display/debug)
        self.answers = []        # matching answers
        self.categories = []     # optional category label per FAQ
        self.cleaned_questions = []

        self._load_faq_data()
        self._build_vector_space()

    # ------------------------------------------------------------------
    # Data loading
    # ------------------------------------------------------------------
    def _load_faq_data(self):
        """Read the FAQ CSV file into memory."""
        if not os.path.exists(self.csv_path):
            raise FileNotFoundError(f"FAQ data file not found at: {self.csv_path}")

        with open(self.csv_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                question = row.get("question", "").strip()
                answer = row.get("answer", "").strip()
                category = row.get("category", "general").strip()

                if not question or not answer:
                    continue  # skip malformed rows

                self.questions.append(question)
                self.answers.append(answer)
                self.categories.append(category)

        if not self.questions:
            raise ValueError("No valid FAQ entries were loaded from the CSV.")

        self.cleaned_questions = [clean_text(q) for q in self.questions]

    # ------------------------------------------------------------------
    # Vector space setup
    # ------------------------------------------------------------------
    def _build_vector_space(self):
        """
        Fit a TF-IDF vectorizer on all FAQ questions. This builds the
        vocabulary and IDF weights once; every subsequent user query is
        just transformed (not re-fit) into the same space.
        """
        self.vectorizer = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),   # unigrams + bigrams improve short-question matching
            min_df=1,
        )
        self.faq_vectors = self.vectorizer.fit_transform(self.cleaned_questions)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def get_response(self, user_query: str) -> dict:
        """
        Given a raw user query string, return the best-matching FAQ
        answer along with metadata about the match.

        Returns a dict: {"answer": str, "score": float, "matched_question": str|None}
        """
        if not user_query or not user_query.strip():
            return {
                "answer": "Please type a question so I can help you.",
                "score": 0.0,
                "matched_question": None,
            }

        cleaned_query = clean_text(user_query)
        query_vector = self.vectorizer.transform([cleaned_query])

        similarities = cosine_similarity(query_vector, self.faq_vectors).flatten()
        best_index = similarities.argmax()
        best_score = float(similarities[best_index])

        if best_score < SIMILARITY_THRESHOLD:
            return {
                "answer": FALLBACK_MESSAGE,
                "score": best_score,
                "matched_question": None,
            }

        return {
            "answer": self.answers[best_index],
            "score": best_score,
            "matched_question": self.questions[best_index],
        }


# ---------------------------------------------------------------------------
# Simple manual test when running this file directly:
#   python chatbot.py
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    bot = FAQChatbot()
    print(f"Loaded {len(bot.questions)} FAQ entries.\n")

    test_queries = [
        "How do I apply for admission?",
        "hostel fee kitna hai",
        "what time does library open",
        "tell me a joke",
    ]
    for q in test_queries:
        result = bot.get_response(q)
        print(f"Q: {q}")
        print(f"A: {result['answer']}  (score={result['score']:.2f})\n")
